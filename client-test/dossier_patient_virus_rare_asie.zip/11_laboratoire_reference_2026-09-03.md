# Laboratoire spécialisé — 03/09/2026
Prélèvements adressés via filière de référence : échantillons respiratoires et sanguins collectés le 31/08.
Résultat communiqué : détection d'ARN du virus Nipah par RT-PCR spécifique sur un prélèvement respiratoire ; confirmation par seconde cible moléculaire dans le laboratoire de référence. Prélèvement sanguin : résultat indéterminé, non interprétable. Les résultats sont communiqués à l'équipe spécialisée et aux autorités sanitaires selon les procédures applicables.
Cette information est un résultat de laboratoire fictif, non une instruction de manipulation d'échantillons.
