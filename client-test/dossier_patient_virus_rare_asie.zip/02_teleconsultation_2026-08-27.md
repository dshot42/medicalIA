# Téléconsultation — 27/08/2026
Motif : fièvre depuis le 26/08, céphalées, courbatures, fatigue, nausées. Température maximale déclarée 38,8 °C. Pas de toux ni dyspnée. Pas de diarrhée. Orientation vers consultation présentielle compte tenu du retour récent d'Asie et de la fièvre. Aucun diagnostic établi.
