# Résultats microbiologiques — 29/08/2026
Test paludisme (goutte épaisse et frottis) : négatif sur premier prélèvement ; contrôle à prévoir si suspicion maintenue.
RT-PCR dengue : négative sur prélèvement du 28/08.
PCR SARS-CoV-2 et influenza A/B : négatives.
Hémocultures prélevées le 28/08 : en cours à cette date.
Note : ces résultats ne suffisent pas à exclure l'ensemble des infections importées.
