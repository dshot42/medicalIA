# CORRIGÉ — À NE PAS IMPORTER POUR UN TEST AVEUGLE
Diagnostic final fictif : infection par virus Nipah avec encéphalite.
Preuve décisive : RT-PCR spécifique confirmée par seconde cible sur prélèvement respiratoire, datée du 03/09/2026.
Indices antérieurs : séjour au Bangladesh, consommation de sève de palmier crue, fièvre suivie de confusion/somnolence, syndrome inflammatoire modéré, LCR lymphocytaire, IRM compatible mais non spécifique.
Limites : aucun de ces indices pris isolément ne confirme Nipah ; le premier test paludisme négatif ne suffit pas seul à exclure le paludisme ; la voie exacte de contamination demeure incertaine ; les images IRM ne sont pas spécifiques.
TESTS LOGICIELS : (1) avant 03/09, classer Nipah comme hypothèse à explorer et non confirmation ; (2) après 03/09, reconnaître la confirmation microbiologique ; (3) distinguer date d'exposition, début des symptômes et date de documentation ; (4) ne pas inventer de contact direct avec des chauves-souris ; (5) détecter l'évolution neurologique ; (6) distinguer test indéterminé du test négatif ; (7) ne pas importer ce corrigé dans le RAG patient.
