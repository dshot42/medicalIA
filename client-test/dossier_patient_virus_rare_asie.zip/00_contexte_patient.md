# DOSSIER FICTIF — CAS ASIE 2026
Identifiant : PAT-SEA-042. Tous les noms, dates, lieux de soins et résultats sont inventés à des fins de test logiciel. Aucune donnée réelle.
Patient : homme, 32 ans, sans maladie chronique connue. Vaccinations usuelles à jour selon déclaration. Voyage du 03/08/2026 au 25/08/2026 : Bangladesh (Dhaka, puis district rural) et escale à Bangkok. Retour en France le 25/08/2026.
Objectif du jeu de données : éprouver la reconstruction temporelle, les hypothèses concurrentes, la détection de contradictions, les examens discriminants et la gestion de l'incertitude. Le diagnostic final figure dans un dossier distinct, à ne pas importer lors du test aveugle.
